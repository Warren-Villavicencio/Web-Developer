<template>
  <div class="container">
    <h1>Cookiecutter Django Vue</h1>
    <p align="center">
      <img src="https://i.imgur.com/SA8cjs8.png">
    </p>
  </div>
</template>

<script>
export default {
  name: 'FirstComponent'
}
</script>

<style lang="scss" scoped>
  h1 {
    text-align: center;
  }
</style>
